# Elite Care - PHP Backend

باك إند PHP + MySQL كامل لمشروع مستشفى النخبة الطبية، بديل عن نظام الـ localStorage الحالي في `main.js`.

## 1. التشغيل على جهازك (XAMPP)

1. حمّل XAMPP وشغّل **Apache** و **MySQL**.
2. انسخ فولدر `elitecare-backend` بالكامل جوه `htdocs` (مثلاً: `C:\xampp\htdocs\elitecare-backend`).
3. افتح **phpMyAdmin** (`http://localhost/phpmyadmin`) واستورد ملف `sql/schema.sql` (تبويب Import).
4. غيّر باسورد الأدمن الافتراضي: شغّل السطر ده في أي terminal عندك فيه PHP:
   ```
   php -r "echo password_hash('كلمة_سر_قوية', PASSWORD_DEFAULT);"
   ```
   وانسخ الناتج بدل `$2y$10$CHANGE_THIS_HASH` في جدول `users` (صف الأدمن) من phpMyAdmin.
5. تأكد إن بيانات الاتصال في `config/db.php` مطابقة لإعدادات XAMPP عندك (افتراضياً: `root` بدون باسورد).
6. الباك إند هيشتغل على: `http://localhost/elitecare-backend/`

## 2. هيكل الملفات

```
elitecare-backend/
├── config/db.php              -- الاتصال بقاعدة البيانات
├── includes/functions.php     -- دوال مساعدة (sessions, json response...)
├── sql/schema.sql             -- بنية قاعدة البيانات
├── auth/
│   ├── register.php
│   ├── login.php
│   ├── logout.php
│   ├── forgot_password.php
│   └── reset_password.php
├── profile/
│   ├── get_profile.php
│   └── update_profile.php
├── appointments/
│   ├── book_appointment.php
│   ├── get_appointments.php
│   ├── cancel_appointment.php
│   └── reschedule_appointment.php
├── doctors/
│   ├── get_doctors.php
│   └── manage_doctor.php      -- (أدمن) إضافة/تعديل/حذف
├── services/
│   ├── get_services.php
│   └── manage_service.php     -- (أدمن) إضافة/تعديل/حذف
├── reviews/
│   ├── get_reviews.php
│   └── submit_review.php
├── search/search.php
└── admin/
    ├── get_all_appointments.php
    ├── update_appointment_status.php
    ├── delete_appointment.php
    ├── get_users.php
    └── delete_user.php
```

## 3. طريقة الربط مع main.js الحالي

كل ملف بيرجع JSON بالشكل: `{ success: true/false, message, ...بيانات }`
لازم تستبدل استدعاءات `localStorage` بـ `fetch()`. أهم نقطة: لازم تضيف
`credentials: 'include'` في كل fetch عشان الـ session (تسجيل الدخول) يفضل شغال.

### مثال: تسجيل الدخول
```javascript
// بدل: Auth.login(email, password)
async function login(email, password, remember) {
    const res = await fetch('http://localhost/elitecare-backend/auth/login.php', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, remember })
    });
    return await res.json();
}
```

### مثال: حجز موعد
```javascript
async function bookAppointment(appointmentData) {
    const res = await fetch('http://localhost/elitecare-backend/appointments/book_appointment.php', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(appointmentData)
    });
    return await res.json();
}
```

### مثال: البحث الحي
```javascript
async function liveSearch(query) {
    const res = await fetch(`http://localhost/elitecare-backend/search/search.php?q=${encodeURIComponent(query)}`, {
        credentials: 'include'
    });
    const data = await res.json();
    return data.results;
}
```

## 4. ملاحظات أمان مهمة قبل الرفع فعلياً

- غيّر `DB_USER` و `DB_PASS` في `config/db.php` لو رفعت المشروع على استضافة حقيقية.
- في `includes/functions.php`، دالة `allowCors()` مفتوحة لأي دومين (`*`) لتسهيل التطوير فقط — قبل النشر خليها تسمح بدومينك بس.
- سجل دخول الأدمن بيتم من نفس فورم تسجيل الدخول العادي، وبيتحدد حسب عمود `is_admin` في قاعدة البيانات (مش إيميل/باسورد ثابتين زي الكود القديم).
- كل الباسوردات متخزنة مشفرة بـ `password_hash()`، ومفيش أي باسورد بيتخزن نص عادي.
